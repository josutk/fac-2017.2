#ifndef _IN_OUT
#define _IN_OUT
#include "tiposCompostos.h"

CartesianPoint readPoint(double x , double y );
void showResult(Circle circle);
void notAcircleMessage();
void menu();

#endif
